# A Pérola dos Sete Ventos · GitHub Pages · P0.0

Site HTML/CSS independente de WordPress, sem dependências, sem pagamentos e compatível com GitHub Pages.

## Prioridade urgente

- `ficcao/cracfics/reuniao-pre-tour-dragoes-raizes-ramen-e-pinguins/` — **Reunião Pré-Tour: Dragões, Raízes, Ramen e… Pinguins?** (cracfic one-shot; capa e sinopse original recuperadas)
- `ficcao/cracfics/o-dia-em-que-ninguem-reconheceu-o-sol/` — **O Dia em que Ninguém Reconheceu o Sol** (cracfic one-shot; título e género originais confirmados)

**IMPORTANTE:** Os textos integrais não estão neste pacote. WordPress suspendeu o acesso ao conteúdo, não houve exportação e não foi encontrada cópia fiável em conversas ou arquivos. As páginas apresentam um aviso honesto de recuperação, em vez de conteúdo reescrito sem autorização.

## Publicação

1. Em `https://github.com/new`, criar o repositório público `perola7ventos` (conta `ScallopDragonARMY`). **Não usar os projetos KPopMerchMaker ou PlaylistMaker.**
2. Na raiz do novo repositório, adicionar todos os ficheiros deste pacote, preservando as pastas `assets/`, `ficcao/` e `sobre/`. É possível arrastar os ficheiros via **Add file → Upload files** ou usar `git`.
3. Em **Settings → Pages**, escolher **Deploy from a branch → main → / (root) → Save**.
4. URL previsto *após ativação*: `https://ScallopDragonARMY.github.io/perola7ventos/`. Confirmar a URL no painel do GitHub: ainda não está publicada.

## Recuperação dos textos

Quando forem obtidos os originais exatos, substituir o elemento `<aside class="restoration">...</aside>` de cada `ficcao/cracfics/reuniao-pre-tour-dragoes-raizes-ramen-e-pinguins/index.html` e `ficcao/cracfics/o-dia-em-que-ninguem-reconheceu-o-sol/index.html` por parágrafos HTML dentro de `<div class="reader-body">`. Preservar o resto do layout. Não preencher com conteúdo inventado.

## Estrutura

`index.html` página principal, `ficcao/` biblioteca, `ficcao/cracfics/` categoria, `sobre/` sobre, `assets/style.css` CSS completo, `.nojekyll` GitHub Pages estático.

## Verificações

- Caminhos relativos compatíveis com GitHub Pages no subdiretório do repositório
- Sem mosaicos nem imagens repetidas sobre o texto
- Menu com 18px
- Ficção justificada e legível
- Sem formulários públicos falsos nem serviços de comentários inventados
